var searchData=
[
  ['hes_5fupd',['hes_upd',['../dfp_8cpp.html#a37b1e21d86fac73141bd858016af2685',1,'hes_upd(Function f, Matrix &amp;B, Vector &amp;x_cur, Vector &amp;x_prv):&#160;dfp.cpp'],['../dfp_8h.html#a37b1e21d86fac73141bd858016af2685',1,'hes_upd(Function f, Matrix &amp;B, Vector &amp;x_cur, Vector &amp;x_prv):&#160;dfp.cpp']]],
  ['hess',['hess',['../group__math.html#ga367226fffe533d54eb320974e8b85117',1,'hess(Function f, const Vector &amp;x, const ld h):&#160;Math.cpp'],['../group__math.html#ga367226fffe533d54eb320974e8b85117',1,'hess(Function f, const Vector &amp;x, const ld h=1e-4):&#160;Math.cpp']]]
];
