var searchData=
[
  ['linmin',['linmin',['../group___powell.html#ga2d3a6af4c089b4ba8552d2ce814b9131',1,'linmin(Vector &amp;p, Vector &amp;xi, ld &amp;fret, Function f):&#160;Powell.cpp'],['../group___powell.html#ga2d3a6af4c089b4ba8552d2ce814b9131',1,'linmin(Vector &amp;p, Vector &amp;xi, ld &amp;fret, Function f):&#160;Powell.cpp']]]
];
