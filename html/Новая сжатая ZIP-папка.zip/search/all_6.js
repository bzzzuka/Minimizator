var searchData=
[
  ['ld',['ld',['../_math_8h.html#a09bfe86a130ac3370740e01ab26b8b48',1,'Math.h']]],
  ['linmin',['linmin',['../group___powell.html#ga2d3a6af4c089b4ba8552d2ce814b9131',1,'linmin(Vector &amp;p, Vector &amp;xi, ld &amp;fret, Function f):&#160;Powell.cpp'],['../group___powell.html#ga2d3a6af4c089b4ba8552d2ce814b9131',1,'linmin(Vector &amp;p, Vector &amp;xi, ld &amp;fret, Function f):&#160;Powell.cpp']]]
];
