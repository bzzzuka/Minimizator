var searchData=
[
  ['dfp',['dfp',['../dfp_8cpp.html#ab84142310beb44f23d9dc3c427d934dc',1,'dfp(Function f, Vector start_point, int iter_limit):&#160;dfp.cpp'],['../dfp_8h.html#a1705392a55410d1683e4f373355857dc',1,'dfp(Function f, Vector start_point, int iter_limit=100):&#160;dfp.cpp']]],
  ['dfp_2ecpp',['dfp.cpp',['../dfp_8cpp.html',1,'']]],
  ['dfp_2eh',['dfp.h',['../dfp_8h.html',1,'']]],
  ['dot',['dot',['../group__math.html#gabae65c71e4ed9b568e382a23cfe75ead',1,'dot(const Vector &amp;v1, const Vector &amp;v2):&#160;Math.cpp'],['../group__math.html#gabae65c71e4ed9b568e382a23cfe75ead',1,'dot(const Vector &amp;v1, const Vector &amp;v2):&#160;Math.cpp']]]
];
