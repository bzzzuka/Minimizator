var indexSectionsWithContent =
{
  0: "cdfghilmnoprstvÐ",
  1: "dmprst",
  2: "dfghilmnops",
  3: "c",
  4: "flmv",
  5: "Ð",
  6: "Ð"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "groups",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Typedefs",
  5: "Modules",
  6: "Pages"
};

