var searchData=
[
  ['powell',['powell',['../group___powell.html#gae8f60240583d4a12b09a1a79d42bccb5',1,'powell(Function f, Vector start_point, int n):&#160;Powell.cpp'],['../group___powell.html#gae8f60240583d4a12b09a1a79d42bccb5',1,'powell(Function f, Vector start_point, int iter_limit=100):&#160;Powell.cpp']]],
  ['powell1',['powell1',['../group___powell.html#gaa1b732c398a91194896a9f259651a007',1,'powell1(Vector &amp;p, ld **xi, const ld ftol, int &amp;iter, ld &amp;fret, Function func):&#160;Powell.cpp'],['../group___powell.html#gaa1b732c398a91194896a9f259651a007',1,'powell1(Vector &amp;p, ld **xi, const ld ftol, int &amp;iter, ld &amp;fret, Function f):&#160;Powell.cpp']]]
];
