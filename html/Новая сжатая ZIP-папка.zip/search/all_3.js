var searchData=
[
  ['grad',['grad',['../group__math.html#ga28bad9316c380d476ae0d4da20d66fa8',1,'grad(Function f, const Vector &amp;point, const ld h):&#160;Math.cpp'],['../group__math.html#ga28bad9316c380d476ae0d4da20d66fa8',1,'grad(Function f, const Vector &amp;point, const ld h=1e-4):&#160;Math.cpp']]]
];
