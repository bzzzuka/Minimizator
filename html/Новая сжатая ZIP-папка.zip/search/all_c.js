var searchData=
[
  ['search_5falpha',['search_alpha',['../dfp_8cpp.html#a0fe4d00ec95a3d1768decf0a26686b1e',1,'search_alpha(Function f, Vector &amp;x, Vector &amp;p, int iter_limit):&#160;dfp.cpp'],['../dfp_8h.html#a0fe4d00ec95a3d1768decf0a26686b1e',1,'search_alpha(Function f, Vector &amp;x, Vector &amp;p, int iter_limit):&#160;dfp.cpp']]],
  ['sign',['SIGN',['../group__math.html#gad52e1ac9693ae72820e7d69bbe852451',1,'SIGN(const ld &amp;a, const ld &amp;b):&#160;Math.cpp'],['../group__math.html#gad52e1ac9693ae72820e7d69bbe852451',1,'SIGN(const ld &amp;a, const ld &amp;b):&#160;Math.cpp']]],
  ['sqr',['SQR',['../group__math.html#gadf27a78bcfeabf971050152b19be7c4f',1,'SQR(const ld a):&#160;Math.cpp'],['../group__math.html#gadf27a78bcfeabf971050152b19be7c4f',1,'SQR(const ld a):&#160;Math.cpp']]],
  ['stdafx_2ecpp',['stdafx.cpp',['../stdafx_8cpp.html',1,'']]],
  ['stdafx_2eh',['stdafx.h',['../stdafx_8h.html',1,'']]],
  ['swap',['SWAP',['../group__math.html#gae2505a6742c775fecef7827df0f58fc3',1,'SWAP(ld &amp;a, ld &amp;b):&#160;Math.cpp'],['../group__math.html#gae2505a6742c775fecef7827df0f58fc3',1,'SWAP(ld &amp;a, ld &amp;b):&#160;Math.cpp']]]
];
