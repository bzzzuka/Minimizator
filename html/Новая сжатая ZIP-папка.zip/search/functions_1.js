var searchData=
[
  ['f1',['f1',['../_minimize_8cpp.html#a6090da0b1977c4f00df127246d4f167f',1,'Minimize.cpp']]],
  ['f1dim',['f1dim',['../group___powell.html#ga4c5ddf0720a91a31ef25ea91d6749b41',1,'f1dim(const ld x, int ncom, Vector *pcom_p, Vector *xicom_p, Function nrfunc):&#160;Powell.cpp'],['../group___powell.html#ga4c5ddf0720a91a31ef25ea91d6749b41',1,'f1dim(const ld x, int ncom, Vector *pcom_p, Vector *xicom_p, Function f):&#160;Powell.cpp']]]
];
